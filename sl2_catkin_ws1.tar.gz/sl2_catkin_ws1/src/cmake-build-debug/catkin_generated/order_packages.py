# generated from catkin/cmake/template/order_packages.context.py.in
source_root_dir = '/home/hongxt/Desktop/sl2_catkin_ws1/src'
whitelisted_packages = ''.split(';') if '' != '' else []
blacklisted_packages = ''.split(';') if '' != '' else []
underlay_workspaces = '/home/hongxt/Desktop/sl2_catkin_ws/devel;/home/hongxt/catkin_ws/devel;/opt/ros/kinetic'.split(';') if '/home/hongxt/Desktop/sl2_catkin_ws/devel;/home/hongxt/catkin_ws/devel;/opt/ros/kinetic' != '' else []
