# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/hongxt/Desktop/sl2_catkin_ws1/src/grid_path_searcher/include".split(';') if "/home/hongxt/Desktop/sl2_catkin_ws1/src/grid_path_searcher/include" != "" else []
PROJECT_CATKIN_DEPENDS = "".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "grid_path_searcher"
PROJECT_SPACE_DIR = "/home/hongxt/Desktop/sl2_catkin_ws1/src/cmake-build-debug/devel"
PROJECT_VERSION = "0.0.1"
